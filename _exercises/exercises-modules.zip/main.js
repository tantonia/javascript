import hello from "./greeting.js";

hello();
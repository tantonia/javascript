export default function hello() {
    console.log("Hello World!");
}